import sys,json,random,collections,datetime,time
sys.path.insert(0,str(__import__('pathlib').Path(__file__).resolve().parent))
import cfb_model as m
con=json.load(open('./cfb_conference_games.json'));nc=json.load(open('./cfb_nonconference_games.json'));g6=json.load(open('./cfb_g6_games.json'))
games=m.make_game_records(con,nc,g6)

def schedule_year(gl,seed=34):
 random.seed(seed);n=len(gl);wcount=14
 fixed={};collisions=[]
 for i,g in enumerate(gl):
  k=frozenset((g['Home'],g['Away']))
  if g['Requested week'] is not None:fixed[i]=g['Requested week']
  elif k==frozenset(('California','Stanford')):fixed[i]=12
  elif k==frozenset(('Iowa','Iowa State')):fixed[i]=2
  elif k in m.LAST_KEYS and k!=frozenset(('Oklahoma','Oklahoma State')):fixed[i]=13
 # handle shared pinned games prioritizing published pinned
 seen={}
 for i in sorted(fixed,key=lambda ix:(gl[ix]['Requested week'] is None,gl[ix]['Type']=='G6')):
  w=fixed[i];ts=(gl[i]['Home'],gl[i]['Away'])
  if any((t,w) in seen for t in ts):
   collisions.append((gl[i]['Home'],gl[i]['Away'],w))
   del fixed[i]
   continue
  for t in ts:seen[(t,w)]=i
 costs={}
 for i,g in enumerate(gl):
  for w in range(14):
   if g['Type']=='Conference':c=1.7 if w<=2 else (.35 if w<=4 else .13)
   elif g['Type']=='G6':c=max(0,w-3)*.35 + (1 if w>9 else 0)
   else:c=max(0,w-3)*.16+(1 if w>9 else 0)
   # risk of saturating same small set of weeks for 12-game teams
   costs[(i,w)]=c
 # each year stable but restarting order
 def try_once(restart):
  assign={};used={};members=collections.defaultdict(dict)
  def setcol(i,w):
   assign[i]=w
   for t in (gl[i]['Home'],gl[i]['Away']):members[t][w]=i
  def unset(i):
   w=assign.pop(i)
   for t in (gl[i]['Home'],gl[i]['Away']):del members[t][w]
  for i,w in fixed.items():setcol(i,w)
  remain=[i for i in range(n) if i not in fixed]
  random.shuffle(remain)
  # place highly connected P4 earlier; nonconf first helps meet preferred date
  remain.sort(key=lambda i:(-(len(members[gl[i]['Home']])+len(members[gl[i]['Away']])),gl[i]['Type']=='Conference',random.random()))
  for i in remain:
   a,b=gl[i]['Home'],gl[i]['Away']
   av=set(range(14))-set(members[a]);bv=set(range(14))-set(members[b]);common=av&bv
   if common:
    w=min(common,key=lambda ww:costs[(i,ww)]+random.random()*.55+.018*sum(x==ww for x in assign.values()))
    setcol(i,w);continue
   # Kempe recolor alternating a-week and b-week chain
   worked=False
   for ua,ub in [(a,b),(b,a)]:
    fa=list(set(range(14))-set(members[ua]));fb=list(set(range(14))-set(members[ub]));random.shuffle(fa);random.shuffle(fb)
    for wa in fa:
     if worked:break
     for wb in fb:
      if wa==wb:continue
      # component in union of edges colored wa/wb
      touched={ua};queue=[ua];component=set()
      while queue:
       node=queue.pop()
       for w in (wa,wb):
        j=members[node].get(w)
        if j is None or j in component:continue
        component.add(j)
        opp=gl[j]['Away'] if gl[j]['Home']==node else gl[j]['Home']
        if opp not in touched:touched.add(opp);queue.append(opp)
      if ub in touched or any(j in fixed for j in component):continue
      # swap colors on component
      oldcolors={j:assign[j] for j in component}
      for j in component:unset(j)
      for j in component:setcol(j,wb if oldcolors[j]==wa else wa)
      setcol(i,wb)
      worked=True
      break
    if worked:break
   if not worked:return None,collisions,i
  return assign,collisions,None
 for restart in range(150):
  sol,collisions,failed=try_once(restart)
  if sol is not None:
   for i,w in sol.items():
    gl[i]['Week']=w;gl[i]['Date']=m.saturdays(gl[i]['Year'])[w].isoformat();gl[i]['Week label']=f'Week {w}'
   return collisions,restart
 return collisions,None

if __name__=='__main__':
 for year in m.YR:
  gl=[g for g in games if g['Year']==year]
  now=time.time();collisions,restart=schedule_year(gl,year)
  print('YEAR',year,'restarts',restart,'time',round(time.time()-now,2),'collisions',collisions,flush=True)
  if restart is None:break
 else:
  json.dump(games,open('./cfb_full_games.json','w'))
  issues=m.validations(games)
  json.dump(issues,open('./cfb_validation_issues.json','w'))
  print('GAMES',len(games),'ERRORS',len(issues),'SAMPLE',issues[:8],flush=True)

