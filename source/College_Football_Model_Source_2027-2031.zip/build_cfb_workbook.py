import sys,os,json,collections,itertools,datetime,math,csv
sys.path.insert(0,str(__import__('pathlib').Path(__file__).resolve().parent))
import cfb_model as m
from artifact_tool import Workbook, SpreadsheetFile
G=json.load(open('./cfb_full_games.json'))
assert len(G)==2210 and not m.validations(G)
G6_OVERRIDES=json.load(open('./g6_venue_overrides.json'))
assert len(G6_OVERRIDES)==68 and sum(x['Prior']['Status']=='Published' for x in G6_OVERRIDES)==7
S=sorted(G,key=lambda g:(g['Year'],g['Week'], {'Conference':0,'P4 nonconference':1,'G6':2}[g['Type']],g['Home'],g['Away']))
by_team=collections.defaultdict(list)
for g in G:
 for t in (g['Home'],g['Away']):
  if t in m.ALL:by_team[(g['Year'],t)].append(g)
def opponent(g,t):return g['Away'] if t==g['Home'] else g['Home']
def site(g,t):
 if g['Site type']=='Neutral':return 'N'
 return 'H' if t==g['Home'] else 'A'
def matchup(g,t):
 o=opponent(g,t)
 lead='vs ' if site(g,t)=='H' else ('@ ' if site(g,t)=='A' else 'N ')
 typ={'Conference':'C','P4 nonconference':'P','G6':'G'}[g['Type']]
 return f'{lead}{o} [{typ}]'
weekrows=[]
for g in S:
 weekrows.append([g['Year'],g['Week'],g['Date'],g['Away'],g['Home'],m.TEAMCONF.get(g['Away'],m.GC.get(g['Away'],'')),m.TEAMCONF.get(g['Home'],m.GC.get(g['Home'],'')),g['Type'],g['Conference'],g['Venue'],g['Site type'],g['Status'],g['Source URL'],g['Game ID']])
teamrows=[];calrows=[];validationrows=[]
for y in m.YR:
 for t in sorted(m.ALL,key=lambda x:(list(m.CONF.keys()).index(m.TEAMCONF[x]) if m.TEAMCONF[x] in m.CONF else 4,x)):
  gl=sorted(by_team[(y,t)],key=lambda a:a['Week']);assert len(gl)==12
  wks={g['Week']:g for g in gl};cg=sum(g['Type']=='Conference' for g in gl);p4=sum(g['Type']!='G6' for g in gl);g6=sum(g['Type']=='G6' for g in gl)
  h=sum(site(g,t)=='H' for g in gl);a=sum(site(g,t)=='A' for g in gl);n=sum(site(g,t)=='N' for g in gl)
  expect=(8 if m.TEAMCONF[t]=='ACC' and t=={2027:'Clemson',2028:'Stanford',2029:'SMU',2030:'California',2031:'Boston College'}[y] else 9) if t!='Notre Dame' else 0
  err=[]
  if cg!=expect:err.append('Conference')
  if p4!=11:err.append('Power')
  if g6!=1:err.append('G6')
  if len(wks)!=12:err.append('Week conflict')
  if len(gl)!=12:err.append('Game total')
  stat='PASS' if not err else '; '.join(err)
  validationrows.append([y,t,m.TEAMCONF[t],len(gl),cg,expect,p4,11-cg,g6,h,a,n,14-len(wks),stat])
  calrows.append([y,t,m.TEAMCONF[t]]+[matchup(wks[w],t) if w in wks else 'BYE' for w in range(14)]+[cg,p4,g6])
  for g in gl:
   opp=opponent(g,t);teamrows.append([y,t,m.TEAMCONF[t],g['Week'],g['Date'],opp,m.TEAMCONF.get(opp,m.GC.get(opp,'')),site(g,t),g['Type'],g['Venue'],g['Status'],g['Game ID'],g['Source URL']])
assert all(a[-1]=='PASS' for a in validationrows)
# Pair coverage: administrative neutral home treated as host for assigning reciprocal fixtures
pairs=[]
for c,teams in m.CONF.items():
 for a,b in itertools.combinations(teams,2):
  matchup_by_y={y:[g for g in G if g['Year']==y and g['Type']=='Conference' and frozenset((g['Home'],g['Away']))==frozenset((a,b))] for y in m.YR}
  games=[item for z in matchup_by_y.values() for item in z]
  ac=sum(g['Home']==a for g in games);bc=sum(g['Home']==b for g in games)
  neutral=any(g['Site type']=='Neutral' for g in games)
  def fmt(y):
   if not matchup_by_y[y]:return '—'
   v=matchup_by_y[y][0]
   return ('N: ' if v['Site type']=='Neutral' else '')+v['Away']+' @ '+v['Home']
  pairs.append([c,a,b,ac,bc,len(games),*[fmt(y) for y in m.YR],'PASS' if ac>=1 and bc>=1 else 'FAIL','Admin home at neutral venue' if neutral else 'Campus home/away'])
assert all(row[-2]=='PASS' for row in pairs)
# protected rivalry matrix (one row per annual fixture)
rivalry_rows=[]
for c,lst in [('SEC',m.SEC_PROT),('Big Ten',m.BIGTEN_PROT),('Big 12',m.BIG12_PROT),('ACC',m.ACC_PROT),('Cross-conference',m.CROSS_RIVAL)]:
 for a,b in lst:
  for y in m.YR:
   matches=[g for g in G if g['Year']==y and {a,b}=={g['Home'],g['Away']}]
   assert len(matches)==1,(c,a,b,y)
   g=matches[0]
   rivalry_rows.append([c,a,b,y,g['Week'],g['Date'],g['Away'],g['Home'],g['Venue'],g['Site type'],g['Status'],g['Source URL']])
# 5-year nonconference calendar fairness across league pairs
nc=[g for g in G if g['Type']=='P4 nonconference']
conf_order=['SEC','Big Ten','Big 12','ACC','Independent']
interbalance=[]
for a,b in itertools.combinations(conf_order,2):
 sub=[g for g in nc if {m.TEAMCONF[g['Home']],m.TEAMCONF[g['Away']]}=={a,b}]
 counts=collections.Counter(g['Year'] for g in sub)
 interbalance.append([a,b]+[counts[y] for y in m.YR]+[len(sub),round(len(sub)/5,1),max(counts.values())-min(counts.values())])
# granular team by other conference values
cross_matrix=[]
for t in sorted(m.ALL):
 for c in conf_order:
  if c==m.TEAMCONF[t]:continue
  sub=[g for g in nc if t in (g['Home'],g['Away']) and m.TEAMCONF[opponent(g,t)]==c]
  counts=collections.Counter(g['Year'] for g in sub)
  cross_matrix.append([t,m.TEAMCONF[t],c]+[counts[y] for y in m.YR]+[len(sub),len({opponent(g,t) for g in sub})])
rep=collections.defaultdict(list)
for g in nc:rep[tuple(sorted((g['Home'],g['Away'])))].append(g)
repeats=[]
for (a,b),lst in sorted(rep.items(),key=lambda x:(-len(x[1]),x[0])):
 if len(lst)>1:
  repeats.append([a,b,m.TEAMCONF[a],m.TEAMCONF[b],len(lst),', '.join(str(g['Year']) for g in sorted(lst,key=lambda a:a['Year'])),'PROTECTED' if frozenset((a,b)) in set(map(frozenset,m.CROSS_RIVAL)) else 'Repeat to examine'])
# G6 allocation
G6rows=[]
assert all(g['Home'] in m.TEAMCONF and g['Away'] in m.GC and g['Site type']=='Campus' and g['Venue']==g['Home']+' campus' for g in G if g['Type']=='G6' and 'Notre Dame' not in (g['Home'],g['Away']))
for g in sorted((g for g in G if g['Type']=='G6'),key=lambda z:(z['Year'],z['Week'],z['Home'])):
 t=g['Away'] if g['Away'] in m.ALL else g['Home'];other=opponent(g,t)
 local='Same state' if m.ST[t]==m.GST[other] else ('Same region' if m.REGION[m.ST[t]]==m.REGION[m.GST[other]] else 'Cross-region')
 G6rows.append([g['Year'],t,m.TEAMCONF[t],other,m.GC[other],m.ST[t],m.GST[other],local,site(g,t),g['Week'],g['Date'],g['Venue'],g['Status'],g['Source URL']])
# released fixture completeness: conference only, neutral games assigned as modeling (not official school H/A entry)
confinventory=[]
for y in m.YR:
 for c,teams in m.CONF.items():
  gl=[g for g in G if g['Year']==y and g['Type']=='Conference' and g['Conference']==c]
  published=sum(g['Status']=='Published' for g in gl)
  notes='Published 2027 opponents and sites' if c=='ACC' and y==2027 else ('Published SEC opponents/sites except two neutral games' if c=='SEC' and y<=2029 else ('Published Big Ten 2027–28 opponents and home venues (80 of 81)' if c=='Big Ten' and y<=2028 else ('Partial school venue data; conference pairings modeled' if c=='Big 12' and y==2027 else 'No comprehensive officially published conference slate ingested; modeled rotation')))
  confinventory.append([y,c,len(teams),len(gl),published,len(gl)-published,round(published/len(gl),4),notes,m.URLS[c]])
# audit exception/known hard requirements
exceptions=[
 [2027,'Georgia–Florida','Venue','User preference Jacksonville; published 2027 venue Tampa','Tampa retained; Jacksonville resumes 2028','Published commitment overrides user default because Jacksonville stadium unavailable',m.URLS['FLGA']],
 [2027,'Notre Dame–USC','Rivalry hiatus','Historical annual series, but official hiatus 2027–29','No USC–Notre Dame game in 2027–29; returns 2030–31','Latest contract supersedes annual rivalry convention',m.URLS['USCND']],
 [2028,'Notre Dame–USC','Rivalry hiatus','Historical annual series, but official hiatus 2027–29','No USC–Notre Dame game in 2027–29; returns 2030–31','Latest contract supersedes annual rivalry convention',m.URLS['USCND']],
 [2029,'Notre Dame–USC','Rivalry hiatus','Historical annual series, but official hiatus 2027–29','No USC–Notre Dame game in 2027–29; returns 2030–31','Latest contract supersedes annual rivalry convention',m.URLS['USCND']],
 [2027,'Notre Dame–Georgia Tech','Obsolete historical release','Older Notre Dame–ACC 2017 matrix listed Georgia Tech in 2027','Removed; 2027 ACC opponents follow September 2026 ACC revision','Newer official ACC statement replaces the older projection',m.URLS['GTupdate']],
 [2027,'Notre Dame–Kent State','Second G6 game','Published Notre Dame slate also includes Navy','Navy retained as the sole G6 game','Only one G6 opponent permitted','https://www.on3.com/teams/notre-dame-fighting-irish/news/notre-dame-football-future-schedules-updated-dates-opponents-through-2038/'],
 [2027,'Notre Dame–Navy','Traditional G6 rivalry','Notre Dame plays Navy yearly','Retained annually; all five years','Notre Dame uses Navy for its one permitted G6 slot',m.URLS['NDupdated']],
 [2027,'USC–Nevada','Second G6 game','USC has 2027 games versus both UNLV and Nevada','UNLV retained; Nevada displaced','Only one G6 opponent permitted per Power program','https://usctrojans.com/sports/2018/5/21/usc-football-future-schedules'],
 [2027,'Tennessee–Tennessee State','FCS prohibition','Tennessee State is FCS','Excluded; replaced by model-generated P4 game if needed','FCS prohibited; not equivalent to permitted G6','https://utsports.com/sports/football/schedule/2027'],
 [2028,'Oregon–Sacramento State','FCS prohibition','Sacramento State is FCS','Excluded; Oregon–Oregon State G6 rivalry retained','FCS games prohibited','https://goducks.com/news/2026/8/7/football-oregon-adds-2028-game-against-sacramento-state'],
 [2027,'SEC league home/away','Neutral series','Florida–Georgia and Texas–Oklahoma use neutral sites','Administrative home alternates for coverage calculations','Neutral games do NOT constitute literal campus home/away visits',m.URLS['SEC']],
 [2027,'ACC 17-team format','Uneven conference membership','17 ACC teams cannot all have nine games in one year','16 play 9; one plays 8 each year; rotated across Clemson, Stanford, SMU, California, Boston College','2027 Clemson from actual released opponents; later selections modeled',m.URLS['ACC']],
 [2027,'Future published contracts','Completeness of source ingestion','Contracts across 68 schools through 2031 not all covered by consolidated official sources','Known authoritative fixtures fixed when verified; unverified are modeled rather than guaranteed preserved','Preserving every future announcement requires a comprehensive ongoing contract audit','https://fbschedules.com/']
]
# Explicit contract conflicts arising from the new all-P4-campus G6 venue rule.
for override in G6_OVERRIDES:
 if override['Prior']['Status']!='Published':continue
 y=override['Year'];power=override['Power Team'];g6=override['G6 Opponent']
 prior=override['Prior'];new=override['New']
 exceptions.append([y,f'{power}–{g6}','G6 home-campus requirement',
    f"Previously published: {prior['Away']} @ {prior['Home']}; {prior['Site type']} at {prior['Venue']}",
    f"MODELED OVERRIDE: {g6} @ {power}; {power} campus",
    'All G6 games must be on the P4 campus except Notre Dame–Navy; original contract requires amendment.',
    prior['Source URL']])
source_rows=[
 ['SEC 2027–29 released conference opponents','SEC',m.URLS['SEC'],'Home-side fixtures for all 16 teams; 2027–29, 70/72 annually'],
 ['ACC 2027 conference opponents','ACC',m.URLS['ACC'],'All 76 conference games in 2027; Clemson eight-game exception'],
 ['Big Ten 2027–28 released opponents','Big Ten',m.URLS['Big Ten'],'80 of 81 fixture venues fixed annually, last inferred in league optimization'],
 ['Big 12 2024–27 league matrix','Big 12',m.URLS['Big 12'],'Subset of 2027 home allocations entered and locked; rest modeled'],
 ['2027–31 Notre Dame ACC historical series','ND / ACC',m.URLS['ND'],'2030–31 ACC slots; 2027 superseded by ACC updated opponent release'],
 ['Notre Dame future opponent contracts','Notre Dame',m.URLS['NDupdated'],'Some 2027–29 opponents; all published dates subject to revisions'],
 ['2027 ACC opponents Georgia Tech revision','ACC / Notre Dame',m.URLS['GTupdate'],'2027 GT–ND canceled, newer ACC overrides old fixture'],
 ['USC–Notre Dame series latest hiatus','Notre Dame / USC',m.URLS['USCND'],'No 2027–29 game; 2030–31 renewal'],
 ['Florida–Georgia venue 2027 and beyond','SEC',m.URLS['FLGA'],'Tampa 2027; Jacksonville 2028–2031'],
 ['Historical neutral-site P4 future commitments','Various',m.URLS['neutral'],'Selected official neutral games with requested dates'],
 ['Tennessee–Georgia Tech moved 2027 kickoff','Tennessee','https://utsports.com/news/2026/9/30/football-moves-2027-and-2028-season-opener-dates','Week 0 2027'],
 ['Ohio State–Alabama series','Ohio State','https://ohiostatebuckeyes.com/news/2023/10/5/football-home-and-away-big-ten-opponents-for-2024-28-announced','Ohio State home 2027; Alabama home 2028'],
 ['Wisconsin vs Pitt 2027 Dublin','Wisconsin','https://uwbadgers.com/sports/football/schedule/2027','Week 0 neutral site'],
 ['Washington future football contracts','Washington','https://gohuskies.com/sports/2013/9/5/209251613/recent','Apple Cup 2027–28 and TN 2029–30'],
 ['USC official future schedules 2027–31','USC','https://usctrojans.com/sports/2018/5/21/usc-football-future-schedules','2027 UNLV retained; Nevada replaced; 2028 Fresno State retained; 2030/31 ND renewals'],
 ['UCLA future schedules','UCLA','https://uclabruins.com/ucla-football-future-schedules','UCLA–California series 2027/28'],
 ['Big 12 BYU home allocations','BYU',m.URLS['BYU'],'2027 partial four year schedule'],
 ['Big 12 TCU home allocations','TCU',m.URLS['TCU'],'2027 conference fixtures'],
 ['Big 12 Colorado home allocations','Colorado',m.URLS['CO'],'2027 conference fixtures'],
]
# Main workbook
wb=Workbook.create()
DARK='#142C43'; TEAL='#0E807F'; GOLD='#D1A343'; SKY='#EAF4F5'
def write_sheet(name,headers,rows,widths=None):
 sh=wb.worksheets.add(name)
 n=len(headers)
 sh.get_range_by_indexes(0,0,1,n).values=[headers]
 sh.get_range_by_indexes(0,0,1,n).format.fill=DARK
 sh.get_range_by_indexes(0,0,1,n).format.font.color='#FFFFFF'
 sh.get_range_by_indexes(0,0,1,n).format.font.bold=True
 sh.get_range_by_indexes(0,0,1,n).format.row_height=26
 for k in range(0,len(rows),450):
  batch=rows[k:k+450]
  sh.get_range_by_indexes(k+1,0,len(batch),n).values=batch
 sh.freeze_panes.freeze_rows(1)
 if widths:
  for j,w in enumerate(widths):
   if w:
    col='';q=j+1
    while q: q,r=divmod(q-1,26);col=chr(65+r)+col
    sh.get_range(f'{col}1:{col}2').format.column_width=w
 return sh
# worksheet list
summary=wb.worksheets.add('01 | Overview')
summary.merge_cells('A1:J2')
summary.get_range('A1').values=[['POWER FOUR + NOTRE DAME  |  2027–2031']]
summary.get_range('A1:J2').format.fill=DARK
summary.get_range('A1:J2').format.font.bold=True
summary.get_range('A1:J2').format.font.color='#FFFFFF'
summary.get_range('A1:J2').format.font.size=19
summary.merge_cells('A3:J3')
summary.get_range('A3').values=[['Five-year scheduling counterfactual • scenario, not official NCAA or conference schedules']]
summary.get_range('A3:J3').format.fill=SKY
summary.get_range('A3:J3').format.font.color=DARK
summary.get_range('A3:J3').format.row_height=25
summary.get_range('A5:B10').values=[['TEAMS',68],['SEASONS',5],['GAMES / YEAR',442],['UNIQUE GAMES',2210],['P4 / TEAM / YEAR',11],['G6 / TEAM / YEAR',1]]
summary.get_range('D5:E10').values=[['CONFERENCE GAMES / YEAR',301],['NONCONF P4 GAMES / YEAR',73],['G6 GAMES / YEAR',68],['TEAM-SEASONS VALIDATED',340],['CONFERENCE PAIRS VERIFIED',len(pairs)],['RIVALRY GAMES VERIFIED',len(rivalry_rows)]]
for r in ['A5:A10','D5:D10']:
 summary.get_range(r).format.fill=SKY
 summary.get_range(r).format.font.bold=True
summary.get_range('B5:B10').format.font.bold=True
summary.get_range('E5:E10').format.font.bold=True
summary.get_range('A12:J12').values=[['YEAR','TEAMS','TOTAL GAMES','CONFERENCE','NONCONF P4','G6','PUBLISHED FIXTURES','CONFERENCE PAIRS PASSED','TEAM RULES PASSED','REPEATED P4 NC PAIRS']]
summary.get_range('A12:J12').format.fill=DARK
summary.get_range('A12:J12').format.font.color='#FFFFFF'
summary.get_range('A12:J12').format.font.bold=True
for k,y in enumerate(m.YR,13):
 gl=[g for g in G if g['Year']==y]
 sumrow=[y,68,len(gl),sum(g['Type']=='Conference' for g in gl),sum(g['Type']=='P4 nonconference' for g in gl),sum(g['Type']=='G6' for g in gl),sum(g['Status']=='Published' for g in gl),len([r for r in pairs if r[-2]=='PASS']),sum(v[0]==y and v[-1]=='PASS' for v in validationrows),sum(len(z)>1 and any(g['Year']==y for g in z) for z in rep.values())]
 summary.get_range_by_indexes(k-1,0,1,10).values=[sumrow]
summary.get_range('A20:J20').format.fill=TEAL
summary.get_range('A20:J20').format.font.color='#FFFFFF'
summary.get_range('A20:J20').format.font.bold=True
summary.merge_cells('A20:J20')
summary.get_range('A20').values=[['HOW TO USE THIS WORKBOOK']]
info=[
 '02 Weekly Games: 2,210 unique games with week, date, site and source URL.',
 '03 Team Calendar: 340 team/season rows; 14 week-by-week slots including 2 byes.',
 '04 Team Games: 4,080 team-centric game rows suitable for filtering and pivoting.',
 '05 Conference H-A: every conference pairing gets an administrative home and away visit within five years.',
 '06 Annual Validation: every P4 and Notre Dame team passes 12 games, 11 Power, 1 G6 and conference quota.',
 '07 Rivalry Locks: every protected annual rivalry is preserved; USC–Notre Dame follows published hiatus.',
 '08 P4 Balance and 09 Team Crossplay: audit distribution across conference combinations.',
 '10 P4 Repeat Audit: lists recurring interleague opponents; annual locked rivalries exempt from minimization.',
 '11 G6 Assignments: 340 G6 games; all P4 G6 visitors play on P4 campus, except ND–Navy.',
 '12 Conference Sources: completeness of verified future published home/away commitments.',
 '13 Contract Exceptions: specific known incompatibilities and modeling decisions.',
 '14 Sources: official source ledger; link for each published fixture also on game row.',
 'IMPORTANT: "Published" describes fixtures verified in selected sources, not a full audit of every future contract.',
 'IMPORTANT: 2027 Florida–Georgia is Tampa under official contract; Jacksonville from 2028. Neutral admin home ≠ campus visit.',
 'IMPORTANT: G6 games ALWAYS hosted on P4 campuses, except annual Notre Dame–Navy; seven published conflicting venues overridden.',
 'IMPORTANT: Week dates of unpinned fixtures are hypothetical; no TV slots or opponent-specific G6 full seasons modeled.'
]
for i,line in enumerate(info,22):
 summary.merge_cells(f'A{i}:J{i}');summary.get_range(f'A{i}').values=[[line]]
 summary.get_range(f'A{i}:J{i}').format.row_height=24
 if i>=35:summary.get_range(f'A{i}:J{i}').format.font.color='#B05C2C'
for col,w in {'A':17,'B':18,'C':20,'D':30,'E':22,'F':23,'G':23,'H':26,'I':24,'J':26}.items():summary.get_range(col+'1:'+col+'2').format.column_width=w
summary.freeze_panes.freeze_rows(3)
write_sheet('02 | Weekly Games',['Year','Week','Saturday','Away','Home','Away League','Home League','Game Category','Conf / G6 League','Venue','Site','Origin','Source URL','Game ID'],weekrows,[11,9,17,22,22,17,17,22,19,43,14,22,56,18])
write_sheet('03 | Team Calendar',['Year','Team','Conference']+[f'Week {i}' for i in range(14)]+['Conf. games','P4 total','G6 total'],calrows,[11,22,16]+[28]*14+[14,14,14])
write_sheet('04 | Team Games',['Year','Team','League','Week','Saturday','Opponent','Opponent League','H/A/N','Category','Venue','Origin','Game ID','Source URL'],teamrows,[11,22,17,10,17,23,17,9,23,43,22,18,56])
write_sheet('05 | Conference H-A',['Conference','Team A','Team B','A admin home','B admin home','Games / 5y','2027','2028','2029','2030','2031','Coverage','Notes'],pairs,[16,24,24,16,16,14,38,38,38,38,38,12,36])
write_sheet('06 | Annual Validation',['Year','Team','Conference','Games','Conf games','Conf required','P4 total','P4 NC','G6','Home','Away','Neutral','Byes','Validation'],validationrows,[11,23,16,11,14,17,14,13,11,11,11,12,11,14])
write_sheet('07 | Rivalry Locks',['Grouping','Team A','Team B','Year','Week','Saturday','Away','Home','Venue','Site','Origin','Source'],rivalry_rows,[19,23,23,10,10,16,22,22,43,14,22,55])
write_sheet('08 | P4 Balance',['League A','League B','2027','2028','2029','2030','2031','5-year Total','Annual Mean','Year-to-Year Range'],interbalance,[18,18,12,12,12,12,12,16,15,22])
write_sheet('09 | Team Crossplay',['Team','Home League','Other League','2027','2028','2029','2030','2031','Total P4 NC','Distinct Opponents'],cross_matrix,[24,18,18,12,12,12,12,12,16,20])
write_sheet('10 | P4 Repeat Audit',['Team A','Team B','League A','League B','Times Met','Seasons','Interpretation'],repeats,[24,24,17,17,15,24,25])
write_sheet('11 | G6 Assignments',['Year','Power Team','Power League','G6 Opponent','G6 League','Power State','G6 State','Regional Affinity','Site','Week','Saturday','Venue','Origin','Source URL'],G6rows,[11,24,16,25,22,16,16,18,10,10,16,45,22,52])
write_sheet('12 | Conference Sources',['Year','Conference','Members','Conference Games','Published Locked','Modeled Games','Source Coverage','Provenance / Source Note','Source URL'],confinventory,[11,17,12,20,21,18,17,67,57])
write_sheet('13 | Contract Exceptions',['Year','Matchup / Issue','Exception Type','Existing Commitment / Issue','Model Treatment','Why','Source URL'],exceptions,[11,35,26,65,70,75,70])
write_sheet('14 | Sources',['Source Label','Organization','URL','Use / Coverage'],source_rows,[51,24,92,92])
# audit-only source and controls
notes=[
 ['Scheduling horizon','2027–2031; 14 weekly Saturday slots incl. Week 0 and two team byes. Default week dates are Saturdays, not published kickoff times.'],
 ['Power population','67 current Power 4 conference football members + Notre Dame = 68'],
 ['Conference games','9 for SEC, Big Ten, Big 12; ACC 16 x9 and 1 x8 per year; Notre Dame 0 conference league games'],
 ['ACC 8-game exceptions','2027 Clemson per official release; 2028 Stanford, 2029 SMU, 2030 California, 2031 Boston College assumed rotating exceptions'],
 ['ND / ACC','At least five ACC matchups annually under existing football arrangement.'],
 ['Power definition','P4 means SEC, Big Ten, Big 12, ACC and Notre Dame independent. Pac-12 counted as G6, despite own FBS conference.'],
 ['FCS games','Forbidden; no FCS opponent in generated set.'],
 ['Rivalries','Conference named protections and six annually recurring cross-league rivalries locked. USC–ND hiatus followed until 2030.'],
 ['Home-and-away test','Each intra-league pair appears at least once with Team A administratively home and once with Team B administratively home over 5 seasons.'],
 ['Neutral exception','Florida–Georgia and Oklahoma–Texas administratively home/away; actually held at designated neutral stadium, not a campus.'],
 ['2027 Georgia–Florida','Published Tampa site preserved, although user preference was Jacksonville; Jacksonville resumes 2028.'],
 ['Published games','Only verified fixtures and selected stadiums entered as hard constraints; gaps are model-generated, not official schedules.'],
 ['P4 rotation','SciPy MILP hard coverage and mandates; annual P4 cross-conference matching minimizes repeat opponents and directional skew.'],
 ['Week allocation','14-color multigraph week assignment with published weeks and rivalry-week pins when feasible; Kempe swaps avoid team double bookings.'],
 ['G6 rotation','One G6 each team each year; prioritizes same state/region; minimizes G6 opponent repeats and same-week double booking.'],
 ['G6 hosting rule','EVERY SEC, Big Ten, Big 12, and ACC game versus a G6 opponent is played at the P4 school home campus. No P4 at G6 road games and no neutral G6 venues. Notre Dame–Navy alone may alternate home/away per its rivalry arrangement. Previously published conflicting locations are explicitly overridden.'],
 ['Power home balance','Conference home count 4–5 for nine-game team, 3–5 for eight-game ACC exception. P4 nonconf home determined by overall target.'],
 ['G6 external calendars','G6 complete schedules not generated; avoid simultaneous duplicate opponent usage on modeled game dates only.'],
 ['Random reproducibility','Python random seed = 20271014; deterministic solver inputs with fixed published fixtures.'],
 ['Official dates / TV','Published pinned dates enforced where entered; other schedules represent plausible hypothetical Saturday placements.'],
 ['Contract completeness','No assertion of exhaustively reading all 68 athletic department 2027–31 future schedule databases; verify further before operational use.'],
 ['Active model scope','Model is a structural scenario and conflict audit; not a mutually ratified future contract calendar.']
]
write_sheet('15 | Assumptions',['Rule or Field','Explanation'],notes,[35,125])
# Live Excel formulas for dashboard/audit indicators; seed data remains the optimizer solution.
summary.get_range('B8').formulas=[["=COUNTA('02 | Weekly Games'!$A$2:$A$2211)"]]
summary.get_range('E8').formulas=[["=COUNTIF('06 | Annual Validation'!$N$2:$N$341,\"PASS\")"]]
summary.get_range('E9').formulas=[["=COUNTIF('05 | Conference H-A'!$L$2:$L$530,\"PASS\")"]]
summary.get_range('E10').formulas=[["=COUNTA('07 | Rivalry Locks'!$A$2:$A$276)"]]
for rr in range(13,18):
 summary.get_range(f'C{rr}').formulas=[[f"=COUNTIF('02 | Weekly Games'!$A$2:$A$2211,$A{rr})"]]
 for col,kind in [('D','Conference'),('E','P4 nonconference'),('F','G6')]:
  summary.get_range(f'{col}{rr}').formulas=[[f'=COUNTIFS(\'02 | Weekly Games\'!$A$2:$A$2211,$A{rr},\'02 | Weekly Games\'!$H$2:$H$2211,\"{kind}\")']]
 summary.get_range(f'G{rr}').formulas=[[f'=COUNTIFS(\'02 | Weekly Games\'!$A$2:$A$2211,$A{rr},\'02 | Weekly Games\'!$L$2:$L$2211,\"Published\")']]
val_sheet=wb.worksheets.get_item('06 | Annual Validation')
val_sheet.get_range('N2:N341').formulas=[[f'=IF(AND(D{i}=12,E{i}=F{i},G{i}=11,I{i}=1,M{i}=2),\"PASS\",\"FAIL\")'] for i in range(2,342)]
print('READY_EXPORT',len(weekrows),len(teamrows),len(calrows),len(pairs),len(rivalry_rows),len(repeats),flush=True)
path='./College_Football_P4_Scheduling_Model_2027-2031.xlsx'
SpreadsheetFile.export_xlsx(wb).save(path)
print('EXPORTED',path,os.path.getsize(path),flush=True)
