College Football 2027–2031 scheduling model: reproducibility package

INPUT RULES
68-team population: 67 Power 4 members + Notre Dame. Each plays 11 Power
opponents and one non-Power FBS opponent per year; FCS prohibited.
Every non-Notre-Dame Power Four program hosts its G6 game ON CAMPUS;
Notre Dame–Navy alone may be played at either home venue. Conflicting
published G6 sites are specifically overridden and logged for auditing. Conference
home/away every opponent over five years, SEC/Big Ten/Big 12 nine games, ACC
sixteen x nine and one x eight.

RUNTIME
Python 3.10+, numpy, scipy, networkx and artifact_tool for Excel output.
The notebook running this model already has these installed. The generated
Excel workbook is supplied separately and can be opened without Python.

RUN
From inside this source directory:
  python solve_matchups.py
  python greedy_slots.py
  python build_cfb_workbook.py

The first step optimizes conference and cross-conference opponents; second
assigns weeks without any overlapping games; third exports the workbook.
Outputs are written in the working directory.

NOTE
This is a reproducible *hypothetical* season-structure scenario. Preserved
verified published contracts are hard constraints but the model does not assert
exhaustive coverage of every school announcement through 2031. Physical neutral
sites (Florida/Georgia, Texas/Oklahoma) use nominal alternating administrative
hosts for conference rotation accounting, not real home campus visits.

Source URLs and known conflicts appear in Excel worksheet tabs 13–15.
