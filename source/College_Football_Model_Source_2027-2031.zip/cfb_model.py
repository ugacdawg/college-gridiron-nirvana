import math,random,itertools,collections,datetime,json,csv,time
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import coo_matrix
import networkx as nx
RNG=random.Random(20271014)
YR=list(range(2027,2032))
CONF={
'SEC':['Alabama','Arkansas','Auburn','Florida','Georgia','Kentucky','LSU','Mississippi State','Missouri','Ole Miss','Oklahoma','South Carolina','Tennessee','Texas','Texas A&M','Vanderbilt'],
'Big Ten':['Illinois','Indiana','Iowa','Maryland','Michigan','Michigan State','Minnesota','Nebraska','Northwestern','Ohio State','Oregon','Penn State','Purdue','Rutgers','UCLA','USC','Washington','Wisconsin'],
'Big 12':['Arizona','Arizona State','Baylor','BYU','Cincinnati','Colorado','Houston','Iowa State','Kansas','Kansas State','Oklahoma State','TCU','Texas Tech','UCF','Utah','West Virginia'],
'ACC':['Boston College','California','Clemson','Duke','Florida State','Georgia Tech','Louisville','Miami','North Carolina','NC State','Pitt','SMU','Stanford','Syracuse','Virginia','Virginia Tech','Wake Forest']}
TEAMCONF={x:c for c,ls in CONF.items() for x in ls};TEAMCONF['Notre Dame']='Independent'
ALL=list(itertools.chain.from_iterable(CONF.values()))+['Notre Dame']
URLS={
'SEC':'https://www.secsports.com/championships/2026-2029-sec-football-opponents-reveal',
'ACC':'https://admin.theacc.com/news/2026/9/16/acc-unveils-2027-football-conference-opponents.aspx',
'Big Ten':'https://msuspartans.com/news/2023/10/5/big-ten-conference-announces-future-football-schedule-formats-for-2024-28',
'Big 12':'https://admin.big12sports.com/documents/2023/11/1/FB_Matrix_24_27.pdf',
'ND':'https://fightingirish.com/news/2017/05/11/notre-dame-acc-football-games-for-2026-2037-now-official',
'NDupdated':'https://www.on3.com/teams/notre-dame-fighting-irish/news/notre-dame-football-future-schedules-updated-dates-opponents-through-2038/',
'GTupdate':'https://ramblinwreck.com/news/2026/09/16/2027-acc-football-opponents',
'USCND':'https://www.cbsnews.com/losangeles/news/usc-notre-dame-football-rivalry-series-2030/',
'FLGA':'https://floridagators.com/news/2024/11/1/football-future-sites-for-annual-florida-georgia-game-set',
'neutral':'https://fbschedules.com/college-football-neutral-site-games/',
'Michigan':'https://d4njeax0ev936.cloudfront.net/sports/2017/6/16/football-future-schedules',
'UGA':'https://sicemdawgs.com/future-uga-football-schedules/',
'TCU':'https://gofrogs.com/news/2023/11/1/big-12-football-opponents-announced-for-next-4-years',
'BYU':'https://byucougars.com/news/2023/11/1/big-12-announces-football-scheduling-matrix-for-2024-2027-seasons',
'CO':'https://cubuffs.com/news/2023/11/1/big-12-announces-2024-27-football-scheduling-matrix?path=football'}
SEC_PROT=[('Alabama','Auburn'),('Alabama','Mississippi State'),('Alabama','Tennessee'),('Arkansas','LSU'),('Arkansas','Missouri'),('Arkansas','Texas'),('Auburn','Georgia'),('Auburn','Vanderbilt'),('Florida','Georgia'),('Florida','Kentucky'),('Florida','South Carolina'),('Georgia','South Carolina'),('Kentucky','South Carolina'),('Kentucky','Tennessee'),('LSU','Ole Miss'),('LSU','Texas A&M'),('Mississippi State','Ole Miss'),('Mississippi State','Vanderbilt'),('Missouri','Oklahoma'),('Missouri','Texas A&M'),('Ole Miss','Oklahoma'),('Oklahoma','Texas'),('Tennessee','Vanderbilt'),('Texas','Texas A&M')]
BIGTEN_PROT=[('Illinois','Northwestern'),('Illinois','Purdue'),('Indiana','Purdue'),('Iowa','Minnesota'),('Iowa','Nebraska'),('Iowa','Wisconsin'),('Maryland','Rutgers'),('Michigan','Michigan State'),('Michigan','Ohio State'),('Minnesota','Wisconsin'),('Oregon','Washington'),('UCLA','USC')]
BIG12_PROT=[('Arizona','Arizona State'),('BYU','Utah'),('Kansas','Kansas State'),('Baylor','TCU'),('Iowa State','Kansas State')]
ACC_PROT=[('California','Stanford'),('Florida State','Miami'),('Duke','North Carolina'),('North Carolina','NC State'),('NC State','Wake Forest'),('Virginia','Virginia Tech'),('Clemson','Florida State'),('Boston College','Syracuse')]
PROT={'SEC':SEC_PROT,'Big Ten':BIGTEN_PROT,'Big 12':BIG12_PROT,'ACC':ACC_PROT}
# 2027 ACC complete published home list (ACC Sept 16 2026)
ACC27={
'Boston College':'Georgia Tech,SMU,Stanford,Virginia,Wake Forest',
'California':'Boston College,Florida State,Louisville,SMU',
'Clemson':'Boston College,Florida State,Stanford,Wake Forest',
'Duke':'Boston College,Louisville,Miami,NC State,SMU',
'Florida State':'Duke,Georgia Tech,Louisville,Miami,Stanford',
'Georgia Tech':'California,Pitt,Virginia,Virginia Tech',
'Louisville':'Clemson,North Carolina,Syracuse,Virginia Tech',
'Miami':'California,Georgia Tech,Louisville,Virginia',
'North Carolina':'Duke,Florida State,Virginia,Virginia Tech',
'NC State':'Clemson,Miami,North Carolina,Pitt',
'Pitt':'California,Duke,Miami,SMU,Wake Forest',
'SMU':'Clemson,Georgia Tech,NC State,Stanford',
'Stanford':'California,Duke,North Carolina,Syracuse,Virginia',
'Syracuse':'Boston College,Florida State,North Carolina,NC State,Pitt',
'Virginia':'Louisville,Pitt,SMU,Virginia Tech',
'Virginia Tech':'Clemson,Miami,NC State,Syracuse,Wake Forest',
'Wake Forest':'California,Georgia Tech,North Carolina,NC State,Syracuse'}
# SEC published rows source SEC conference comprehensive: manually transcribed 10 school listings (all 3 years).
SEC_H={
'Alabama':{2027:'Mississippi State,Tennessee,Florida,Missouri,Texas',2028:'Auburn,Kentucky,LSU,Vanderbilt',2029:'Mississippi State,Tennessee,Arkansas,Ole Miss,Oklahoma'},
'Arkansas':{2027:'Texas,Alabama,Kentucky,Ole Miss',2028:'LSU,Missouri,Auburn,Texas A&M,Vanderbilt',2029:'Texas,Florida,Mississippi State,Oklahoma'},
'Auburn':{2027:'Alabama,Georgia,South Carolina,Texas A&M,Oklahoma',2028:'Vanderbilt,Ole Miss,Mississippi State,Tennessee',2029:'Alabama,Georgia,Kentucky,Missouri,Texas'},
'Florida':{2027:'Kentucky,Arkansas,LSU,Texas A&M',2028:'South Carolina,Auburn,Missouri,Texas',2029:'Kentucky,Alabama,Mississippi State,Tennessee'},
'Georgia':{2027:'South Carolina,LSU,Mississippi State,Tennessee',2028:'Auburn,Alabama,Arkansas,Ole Miss',2029:'South Carolina,Kentucky,Texas A&M,Texas'},
'Kentucky':{2027:'South Carolina,Tennessee,Auburn,Georgia,Mississippi State',2028:'Florida,Missouri,Texas A&M,Oklahoma',2029:'South Carolina,Tennessee,Arkansas,Ole Miss,Texas'},
'Missouri':{2027:'Arkansas,Auburn,Tennessee,Vanderbilt',2028:'Texas A&M,Oklahoma,Georgia,Ole Miss,Mississippi State',2029:'Arkansas,Alabama,LSU,South Carolina'},
'Oklahoma':{2027:'Missouri,Alabama,Arkansas,Tennessee',2028:'Ole Miss,Florida,Georgia,Mississippi State',2029:'Missouri,Auburn,LSU,Vanderbilt'},
'South Carolina':{2027:'Florida,LSU,Missouri,Texas',2028:'Georgia,Kentucky,Alabama,Arkansas,Oklahoma',2029:'Florida,Ole Miss,Vanderbilt,Auburn'},
'Vanderbilt':{2027:'Auburn,Mississippi State,South Carolina,Texas,Oklahoma',2028:'Tennessee,Florida,Georgia,Kentucky',2029:'Auburn,Mississippi State,LSU,Missouri,Texas A&M'}
}
# Additional official SEC school schedules completing the released 2027–29 rotation.
SEC_H.update({
'LSU':{2027:'Arkansas,Ole Miss,Missouri,Vanderbilt,Oklahoma',2028:'Texas A&M,Auburn,Kentucky,Tennessee',2029:'Arkansas,Ole Miss,Florida,Georgia,South Carolina'},
'Ole Miss':{2027:'Oklahoma,Alabama,Kentucky,South Carolina',2028:'LSU,Mississippi State,Florida,Vanderbilt,Texas',2029:'Oklahoma,Arkansas,Tennessee,Texas A&M'},
'Mississippi State':{2027:'Ole Miss,Arkansas,Florida,Texas A&M',2028:'Alabama,Vanderbilt,LSU,South Carolina,Texas',2029:'Ole Miss,Georgia,Kentucky,Tennessee'},
'Tennessee':{2027:'Florida,Ole Miss,Mississippi State,Vanderbilt',2028:'Alabama,Arkansas,Kentucky,South Carolina,Texas A&M',2029:'Georgia,Missouri,Oklahoma,Vanderbilt'},
'Texas':{2027:'Texas A&M,Auburn,Georgia,Kentucky',2028:'Arkansas,LSU,Missouri,Tennessee',2029:'Texas A&M,Alabama,South Carolina,Vanderbilt'},
'Texas A&M':{2027:'Georgia,LSU,Missouri,Ole Miss,Vanderbilt',2028:'Alabama,Oklahoma,South Carolina,Texas',2029:'Auburn,Florida,LSU,Mississippi State,Missouri'}})
# Other school partial published lists, 2027/28 Big Ten official.
BT_H={
'Illinois':{2027:'Indiana,Northwestern,Penn State,UCLA,Wisconsin',2028:'Michigan State,Ohio State,Purdue,Washington'},
'Maryland':{2027:'Minnesota,Oregon,Purdue,USC',2028:'Michigan State,Northwestern,Ohio State,Rutgers,Washington'},
'Michigan':{2027:'Illinois,Ohio State,Oregon,Rutgers',2028:'Maryland,Michigan State,Nebraska,Northwestern,USC'},
'Michigan State':{2027:'Indiana,Michigan,Rutgers,Wisconsin',2028:'Iowa,Minnesota,Penn State,Purdue,USC'},
'Minnesota':{2027:'Illinois,Indiana,Ohio State,Washington,Wisconsin',2028:'Iowa,Maryland,Nebraska,Oregon'},
'Nebraska':{2027:'Iowa,Minnesota,Oregon,Purdue,Rutgers',2028:'Northwestern,Penn State,UCLA,Wisconsin'},
'USC':{2027:'Illinois,Indiana,Minnesota,Wisconsin,UCLA',2028:'Iowa,Nebraska,Penn State,Purdue'},
}
# Additional verified 2027-28 Big Ten conference home opponents (published school schedules).
BT_H.update({
'Iowa':{2027:'Maryland,Michigan,Minnesota,UCLA,USC',2028:'Illinois,Nebraska,Rutgers,Wisconsin'},
'Purdue':{2027:'Illinois,Indiana,Michigan State,Penn State,UCLA',2028:'Iowa,Michigan,Nebraska,Northwestern'},
'Oregon':{2027:'Iowa,Ohio State,Penn State,Purdue',2028:'Illinois,Michigan State,Rutgers,USC,Washington'},
'Indiana':{2027:'Iowa,Michigan,Penn State,Rutgers',2028:'Illinois,Maryland,Oregon,Purdue,Washington'},
'Ohio State':{2027:'Michigan State,Purdue,Nebraska,USC',2028:'Michigan,Minnesota,Rutgers,Washington,Wisconsin'},
'Penn State':{2027:'Maryland,Michigan,Michigan State,Washington',2028:'Indiana,Iowa,Ohio State,Oregon,UCLA'},
'Washington':{2027:'Maryland,Michigan State,Nebraska,Oregon,USC',2028:'Michigan,Northwestern,UCLA,Wisconsin'},
'Rutgers':{2027:'Maryland,Northwestern,Ohio State,Washington',2028:'Illinois,Minnesota,Penn State,Purdue,UCLA'},
'Northwestern':{2027:'Maryland,Michigan State,Nebraska,Ohio State,Washington',2028:'Illinois,Indiana,USC,Wisconsin'},
'UCLA':{2027:'Michigan,Northwestern,Oregon,Rutgers',2028:'Indiana,Maryland,Minnesota,Ohio State,USC'},
'Wisconsin':{2027:'Iowa,Nebraska,Northwestern,Penn State',2028:'Indiana,Michigan,Minnesota'}
})
B12_H={
'TCU':{2027:'Arizona State,Texas Tech,Baylor,Houston'},
'BYU':{2027:'Utah,Colorado,Texas Tech,Kansas'},
'Houston':{2027:'Arizona State,BYU,Colorado,Kansas,Texas Tech'},
'Kansas State':{2027:'Baylor,BYU,Cincinnati,Utah,West Virginia'},
'Colorado':{2027:'Arizona State,TCU,Kansas,West Virginia'}
}
FIXED_CONF=collections.defaultdict(dict);FIXED_SOURCE={}
def fix_c(y,c,h,a,url,kind='Published conference opponent / venue'):
 assert h!=a and h in CONF[c] and a in CONF[c]
 k=tuple(sorted((h,a)))
 if k in FIXED_CONF[(c,y)] and FIXED_CONF[(c,y)][k]!=(h,a):raise ValueError(f'conflict {y} {c} {h} {a}: {FIXED_CONF[(c,y)][k]}')
 FIXED_CONF[(c,y)][k]=(h,a);FIXED_SOURCE[(y,k)]=(url,kind)
for c,year_data,src in [('ACC',{2027:ACC27},URLS['ACC']),('SEC',SEC_H,URLS['SEC']),('Big Ten',BT_H,URLS['Big Ten']),('Big 12',B12_H,URLS['Big 12'])]:
 if c=='ACC':
  for h,txt in ACC27.items():
   for a in txt.split(','):fix_c(2027,c,h,a,src)
 else:
  for h,d in year_data.items():
   for y,txt in d.items():
    for a in txt.split(','):fix_c(y,c,h,a,src)
# partial official school source redacted upstream? existing BigTen source 2027 USC home etc, accurate.
print('FIXED CONF',[(c,y,len(FIXED_CONF[(c,y)])) for c in CONF for y in YR if FIXED_CONF[(c,y)]],flush=True)

# model conference: 5-year binary variable per year/ordered edge, row helper

def solve_conference(c, timelimit=65):
 teams=CONF[c]; n=len(teams); idx={t:i for i,t in enumerate(teams)}; nv=5*n*(n-1)
 ids={(y,h,a):i for i,(y,h,a) in enumerate((y,h,a) for y in YR for h in teams for a in teams if h!=a)}
 costs=np.zeros(nv); lb=np.zeros(nv);ub=np.ones(nv)
 for (y,h,a),i in ids.items():
  costs[i]=RNG.random()*.15 + (0.012 if h<a else 0)
 # enforce exact known fixture, and disallow converse
 for y in YR:
  for _,(h,a) in FIXED_CONF[(c,y)].items():
   lb[ids[(y,h,a)]]=ub[ids[(y,h,a)]]=1
   lb[ids[(y,a,h)]]=ub[ids[(y,a,h)]]=0
 # venue split for SEC neutral treat home designation
 for y in YR:
  if c=='SEC':
   # keep UGA Florida and OU TX meeting yearly, but nominal designate alternating home to fulfill directed coverage
   for h,a in [('Florida','Georgia') if y%2 else ('Georgia','Florida'),('Texas','Oklahoma') if y%2 else ('Oklahoma','Texas')]:
    if (y,tuple(sorted((h,a)))) in FIXED_SOURCE: continue
    lb[ids[(y,h,a)]]=ub[ids[(y,h,a)]]=1;lb[ids[(y,a,h)]]=ub[ids[(y,a,h)]]=0
 rows=[];lower=[];upper=[]
 def add(coefs,lo,hi):
  rows.append(coefs);lower.append(lo);upper.append(hi)
 for y in YR:
  for t in teams:
   degree=8 if c=='ACC' and t=={2027:'Clemson',2028:'Stanford',2029:'SMU',2030:'California',2031:'Boston College'}[y] else 9
   add({ids[(y,t,b)]:1 for b in teams if b!=t}|{ids[(y,b,t)]:1 for b in teams if b!=t},degree,degree)
   # home annual cap: 4/5 for 9; 3-5 for 8, except neutral nominal constraints
   hi=5;lo=4 if degree==9 else 3
   add({ids[(y,t,b)]:1 for b in teams if b!=t},lo,hi)
 for h,a in itertools.combinations(teams,2):
  add({ids[(y,h,a)]:1 for y in YR},1,5)  # home-away requirement
  add({ids[(y,a,h)]:1 for y in YR},1,5)
  for y in YR:
   add({ids[(y,h,a)]:1,ids[(y,a,h)]:1},0,1)
  # at most 3 over 5 unless protected, in which case exactly 5
  protected=frozenset((h,a)) in set(map(frozenset,PROT[c]))
  add({ids[(y,h,a)]:1 for y in YR}|{ids[(y,a,h)]:1 for y in YR},5 if protected else 2,5 if protected else 4)
  if protected:
   for y in YR:add({ids[(y,h,a)]:1,ids[(y,a,h)]:1},1,1)
 # total home balance 21-24 over 45 (acc 44/45)
 for t in teams:
  add({ids[(y,t,b)]:1 for y in YR for b in teams if b!=t},20,25)
 rr=[];cc=[];vv=[]
 for r,coefs in enumerate(rows):
  for i,v in coefs.items():rr.append(r);cc.append(i);vv.append(v)
 mat=coo_matrix((np.array(vv,dtype=float),(rr,cc)),shape=(len(rows),nv)).tocsr()
 t0=time.time();res=milp(costs,integrality=np.ones(nv),bounds=Bounds(lb,ub),constraints=LinearConstraint(mat,lower,upper),options={'time_limit':timelimit,'mip_rel_gap':.05})
 print('CONF RESULT',c,res.status,res.message[:90],round(time.time()-t0,1),'objective',res.fun,flush=True)
 if res.x is None:return None
 edges=[]
 for (y,h,a),i in ids.items():
  if res.x[i]>.8:edges.append((y,h,a))
 return edges

# Nonconference P4 pre-announced commitments (some team-side published only) and annual cross-league rivalries.
CROSS_RIVAL=[('Georgia','Georgia Tech'),('Florida','Florida State'),('Clemson','South Carolina'),('Kentucky','Louisville'),('Iowa','Iowa State'),('Pitt','West Virginia')]
FIXED_X=collections.defaultdict(dict);X_SOURCE={};GAME_SPECIAL={};OVERRIDES=[]
def fixx(y,h,a,url,note='Published P4 nonconference commitment',venue=None,week=None):
 assert h!=a and h in ALL and a in ALL and TEAMCONF[h]!=TEAMCONF[a],(y,h,a)
 k=tuple(sorted((h,a)))
 if k in FIXED_X[y] and FIXED_X[y][k]!=(h,a):
  OVERRIDES.append((y,h,a,'CONFLICT: known opposite venue, keeping first',url));return
 FIXED_X[y][k]=(h,a);X_SOURCE[(y,k)]=(url,note)
 if venue or week is not None:GAME_SPECIAL[(y,k)]={'venue':venue,'week':week}
for y in YR:
 for a,b in CROSS_RIVAL:
  # published Georgia Tech Georgia 2027/29/31 at GT; Florida FSU rotate plausible years
  if (a,b)==('Georgia','Georgia Tech'):h,a2=(a,b) if y%2==0 else (b,a)
  else:h,a2=(a,b) if y%2 else (b,a)
  fixx(y,h,a2,URLS['UGA'] if 'Georgia' in (a,b) else 'https://fbschedules.com/',note='Protected annual cross-conference rivalry')
 # section already fixed Louisville Kentucky, etc.
# 2027 specific credible P4 contracts
for y,h,a,url,venue,week in [
 (2027,'Ohio State','Alabama','https://ohiostatebuckeyes.com/news/2023/10/5/football-home-and-away-big-ten-opponents-for-2024-28-announced',None,3),
 (2028,'Alabama','Ohio State','https://ohiostatebuckeyes.com/news/2023/10/5/football-home-and-away-big-ten-opponents-for-2024-28-announced',None,2),
 (2027,'Wisconsin','Pitt','https://uwbadgers.com/sports/football/schedule/2027','Aviva Stadium, Dublin, Ireland',0),
 (2027,'UCLA','California','https://uclabruins.com/ucla-football-future-schedules',None,1),
 (2028,'California','UCLA','https://uclabruins.com/ucla-football-future-schedules',None,1),
 (2030,'Washington','Tennessee','https://gohuskies.com/sports/2013/9/5/209251613/recent',None,1),
 (2027,'Texas','Michigan',URLS['Michigan'],None,1),
 (2027,'Colorado','Northwestern',URLS['CO'],None,2),
 (2027,'Tennessee','Georgia Tech', 'https://utsports.com/news/2026/9/30/football-moves-2027-and-2028-season-opener-dates',None,0),
 (2027,'Notre Dame','Purdue',URLS['NDupdated'],None,1),
 (2027,'Michigan State','Notre Dame',URLS['NDupdated'],None,3),
 (2027,'Notre Dame','Auburn',URLS['NDupdated'],None,4),
 (2027,'Clemson','Notre Dame',URLS['NDupdated'],None,11),
 (2027,'Duke','Notre Dame',URLS['NDupdated'],None,None),
 (2027,'Notre Dame','Virginia Tech',URLS['NDupdated'],None,10),
 (2027,'Stanford','Notre Dame',URLS['NDupdated'],None,13),
 (2027,'Notre Dame','BYU',URLS['BYU'],None,None),
 (2027,'Wake Forest','Notre Dame',URLS['NDupdated'],'Bank of America Stadium, Charlotte, NC',6),
 (2028,'Notre Dame','Texas',URLS['NDupdated'],None,2),
 (2028,'Notre Dame','Arkansas',URLS['NDupdated'],None,3),
 (2028,'Purdue','Notre Dame',URLS['NDupdated'],None,4),
 (2028,'Notre Dame','Clemson',URLS['NDupdated'],None,6),
 (2028,'Notre Dame','Stanford',URLS['NDupdated'],None,7),
 (2028,'Auburn','Notre Dame',URLS['NDupdated'],None,9),
 (2028,'Virginia Tech','Notre Dame',URLS['NDupdated'],None,10),
 (2028,'Notre Dame','Boston College',URLS['NDupdated'],None,None),
 (2028,'Notre Dame','Miami',URLS['NDupdated'],None,None),
 (2028,'Pitt','Notre Dame',URLS['NDupdated'],None,None),
 (2028,'Georgia','Florida State',URLS['neutral'],'Nissan Stadium, Nashville, TN',0),
 (2028,'West Virginia','Tennessee',URLS['neutral'],'Bank of America Stadium, Charlotte, NC',0),
 (2029,'Notre Dame','Alabama',URLS['NDupdated'],None,1),
 (2029,'Texas','Notre Dame',URLS['NDupdated'],None,4),
 (2029,'NC State','Notre Dame',URLS['NDupdated'],None,6),
 (2029,'Clemson','Notre Dame',URLS['NDupdated'],None,10),
 (2029,'Florida State','Notre Dame',URLS['NDupdated'],None,11),
 (2029,'Syracuse','Notre Dame',URLS['NDupdated'],None,None),
 (2029,'Notre Dame','Wake Forest',URLS['NDupdated'],None,None),
 (2029,'Notre Dame','Georgia Tech',URLS['NDupdated'],None,None),
 (2029,'SMU','LSU',URLS['neutral'],'AT&T Stadium, Arlington, TX',1),
 (2029,'Tennessee','Washington','https://utsports.com/sports/2017/6/14/sports-m-footbl-future-schedules-html',None,1),
 (2030,'Georgia','Ohio State',URLS['UGA'],None,2),
 (2030,'Arkansas','Texas Tech',URLS['neutral'],'Allegiant Stadium, Las Vegas, NV',0),
 (2030,'USC','Notre Dame',URLS['USCND'],None,0),
 (2031,'Ohio State','Georgia',URLS['UGA'],None,0),
 (2031,'Notre Dame','USC',URLS['USCND'],None,0),
 (2031,'Virginia Tech','Wisconsin',URLS['neutral'],'Bank of America Stadium, Charlotte, NC',0),
]: fixx(y,h,a,url,venue=venue,week=week)
# 2030/31 ND-ACC 5 published, 2027 already updated, 2028/2029 newer schedule overrides some old original list
for y,match in {
2030:[('Boston College','Notre Dame'),('Notre Dame','Duke'),('Notre Dame','Florida State'),('Louisville','Notre Dame'),('North Carolina','Notre Dame')],
2031:[('Clemson','Notre Dame'),('Notre Dame','Miami'),('North Carolina','Notre Dame'),('Notre Dame','NC State'),('Virginia','Notre Dame')]}.items():
 for h,a in match: fixx(y,h,a,URLS['ND'],note='Notre Dame–ACC published arrangement')
print('FIXED NONCONF',[(y,len(FIXED_X[y]),sum('Notre Dame' in k for k in FIXED_X[y])) for y in YR],flush=True)

def solve_nonconference(confgames):
 stubs={y:{t:11-sum(1 for yy,h,a,c in confgames if yy==y and t in (h,a)) for t in ALL} for y in YR}
 # for conf teams 2 or 3, for ND 11
 for y in YR:
  kcounts=collections.Counter(t for k in FIXED_X[y] for t in k)
  for t,v in kcounts.items():
   if v>stubs[y][t]:raise ValueError(f'Overflow nonconf {y} {t} fixed={v}, available={stubs[y][t]}')
 cand=sorted(tuple(sorted((a,b))) for a,b in itertools.combinations(ALL,2) if TEAMCONF[a]!=TEAMCONF[b]);by_hist=collections.Counter();team_conf_counts=collections.Counter();result=[]
 for y in YR:
  ids={p:i for i,p in enumerate(cand)};n=len(ids);lb=np.zeros(n);ub=np.ones(n);cost=np.zeros(n)
  for (a,b),i in ids.items():
   k=tuple(sorted((a,b)))
   repeat=by_hist[k];cg=TEAMCONF[a];dh=TEAMCONF[b]
   cost[i]=RNG.random()*.4 + repeat*13 + repeat*repeat*2 + .6*(team_conf_counts[(a,dh)]+team_conf_counts[(b,cg)])
   if a=='Notre Dame' or b=='Notre Dame':
    cost[i]-=0.6 if dh=='ACC' or cg=='ACC' else 0
  for k in FIXED_X[y]:lb[ids[k]]=ub[ids[k]]=1
  row=[];lo=[];hi=[]
  def add(coeff,L,H):row.append(coeff);lo.append(L);hi.append(H)
  for t in ALL:
   add({ids[(a,b)]:1 for a,b in cand if t in (a,b)},stubs[y][t],stubs[y][t])
  # ND must face 5 ACC programs minimum in 2027-2031, with 2028 six already hard
  add({ids[(a,b)]:1 for a,b in cand if 'Notre Dame' in (a,b) and (TEAMCONF[a]=='ACC' or TEAMCONF[b]=='ACC')},5,8)
  # cap no more than 4 other-conference teams for small degree, except ND
  for conf in CONF:
   for t in CONF[conf]:
    for dst in CONF:
     if conf==dst:continue
     add({ids[(a,b)]:1 for a,b in cand if t in (a,b) and (TEAMCONF[a]==dst or TEAMCONF[b]==dst)},0,2)
  rr=[];cc=[];vv=[]
  for j,co in enumerate(row):
   for i,v in co.items():rr.append(j);cc.append(i);vv.append(v)
  m=coo_matrix((vv,(rr,cc)),shape=(len(row),n)).tocsr()
  t0=time.time();sol=milp(cost,integrality=np.ones(n),bounds=Bounds(lb,ub),constraints=LinearConstraint(m,lo,hi),options={'time_limit':45,'mip_rel_gap':.10})
  print('NONCONF',y,sol.status,sol.message[:60],round(time.time()-t0,1),flush=True)
  if sol.x is None:raise RuntimeError(f'nonconference infeasible {y}')
  chosen=[k for k,i in ids.items() if sol.x[i]>.5]
  assert len(chosen)==73,(y,len(chosen))
  for a,b in chosen:
   k=(a,b);by_hist[k]+=1;team_conf_counts[(a,TEAMCONF[b])]+=1;team_conf_counts[(b,TEAMCONF[a])]+=1
  result +=[(y,*k) for k in chosen]
 return result

# 2027 football G6 eligible 6 conferences; Pac-12 as G6 with new eight-team lineup.
G6={
'American':['Army','Charlotte','East Carolina','Florida Atlantic','Memphis','Navy','North Texas','Rice','South Florida','Temple','Tulane','Tulsa','UAB','UTSA'],
'CUSA':['Delaware','FIU','Jacksonville State','Kennesaw State','Liberty','Louisiana Tech','Middle Tennessee','Missouri State','New Mexico State','Sam Houston','Western Kentucky'],
'MAC':['Akron','Ball State','Bowling Green','Buffalo','Central Michigan','Eastern Michigan','Kent State','Miami (OH)','Ohio','Toledo','UMass','Western Michigan'],
'Mountain West':['Air Force','Hawaii','Nevada','New Mexico','Northern Illinois','San Jose State','UNLV','UTEP','Wyoming'],
'Pac-12':['Boise State','Colorado State','Fresno State','Oregon State','San Diego State','Texas State','Utah State','Washington State'],
'Sun Belt':['Appalachian State','Arkansas State','Coastal Carolina','Georgia Southern','Georgia State','James Madison','Louisiana','Louisiana-Monroe','Marshall','Old Dominion','South Alabama','Southern Miss','Troy']}
GC={a:c for c,t in G6.items() for a in t};GG=list(GC)
# approximate coordinates: data entry for regional affinity only, not distances or travel times
STATE={
'SEC':['AL','AR','AL','FL','GA','KY','LA','MS','MO','MS','OK','SC','TN','TX','TX','TN'],
'Big Ten':['IL','IN','IA','MD','MI','MI','MN','NE','IL','OH','OR','PA','IN','NJ','CA','CA','WA','WI'],
'Big 12':['AZ','AZ','TX','UT','OH','CO','TX','IA','KS','KS','OK','TX','TX','FL','UT','WV'],
'ACC':['MA','CA','SC','NC','FL','GA','KY','FL','NC','NC','PA','TX','CA','NY','VA','VA','NC']}
ST={a:s for c,ls in CONF.items() for a,s in zip(ls,STATE[c])};ST['Notre Dame']='IN'
G6STATE={
'American':['NY','NC','NC','FL','TN','MD','TX','TX','FL','PA','LA','OK','AL','TX'],
'CUSA':['DE','FL','AL','GA','VA','LA','TN','MO','NM','TX','KY'],
'MAC':['OH','IN','OH','NY','MI','MI','OH','OH','OH','OH','MA','MI'],
'Mountain West':['CO','HI','NV','NM','IL','CA','NV','TX','WY'],
'Pac-12':['ID','CO','CA','OR','CA','TX','UT','WA'],
'Sun Belt':['NC','AR','SC','GA','GA','VA','LA','LA','WV','VA','AL','MS','AL']}
GST={a:s for c,ls in G6.items() for a,s in zip(ls,G6STATE[c])}
G6_FIX={
 (2027,'Notre Dame'):('Navy','Home',None,12,URLS['NDupdated']),
 (2028,'Notre Dame'):('Navy','Away',None,12,URLS['NDupdated']),
 (2029,'Notre Dame'):('Navy','Home',None,12,URLS['NDupdated']),
 (2030,'Notre Dame'):('Navy','Away',None,12,URLS['NDupdated']),
 (2031,'Notre Dame'):('Navy','Home',None,12,URLS['NDupdated']),
 (2027,'Ohio State'):('Bowling Green','Home',None,1,'https://ohiostatebuckeyes.com/news/2023/10/5/football-home-and-away-big-ten-opponents-for-2024-28-announced'),
 (2028,'Ohio State'):('Buffalo','Home',None,1,'https://ohiostatebuckeyes.com/news/2023/10/5/football-home-and-away-big-ten-opponents-for-2024-28-announced'),
 (2027,'Washington'):('Washington State','Away',None,3,'https://gohuskies.com/sports/2013/9/5/209251613/recent'),
 (2028,'Washington'):('Washington State','Home',None,2,'https://gohuskies.com/sports/2013/9/5/209251613/recent'),
 (2028,'Oregon'):('Oregon State','Away',None,3,'https://goducks.com/news/2026/8/7/football-oregon-adds-2028-game-against-sacramento-state'),
 (2027,'Iowa'):('Ball State','Home',None,1,'https://hawkeyesports.com/sports/football/schedule/2027'),
 (2028,'Iowa'):('Western Michigan','Home',None,3,'https://hawkeyesports.com/sports/football/schedule/2028'),
 (2029,'Iowa'):('Northern Illinois','Home',None,3,'https://hawkeyesports.com/sports/football/schedule/2029'),
 (2030,'Iowa'):('Florida Atlantic','Home',None,0,'https://hawkeyesports.com/sports/football/schedule/2030'),
 (2028,'Wisconsin'):('Marshall','Home',None,1,'https://uwbadgers.com/sports/football/schedule/2028'),
 (2027,'USC'):('UNLV','Home',None,1,'https://usctrojans.com/sports/2018/5/21/usc-football-future-schedules'),
 (2028,'USC'):('Fresno State','Home',None,2,'https://usctrojans.com/sports/2018/5/21/usc-football-future-schedules'),
 (2027,'Michigan'):('Buffalo','Home',None,0,URLS['Michigan']),
 (2027,'Nebraska'):('Miami (OH)','Neutral','Arrowhead Stadium, Kansas City, MO',0,URLS['neutral']),
 (2027,'BYU'):('Oregon State','Home',None,0,URLS['BYU']),
 (2028,'BYU'):('Oregon State','Neutral','Allegiant Stadium, Las Vegas, NV',1,URLS['neutral']),
 (2029,'BYU'):('Colorado State','Home',None,2,URLS['BYU']),
 (2030,'BYU'):('Northern Illinois','Away',None,3,URLS['BYU']),
 (2031,'BYU'):('Navy','Home',None,None,URLS['BYU']),
 (2029,'Georgia'):('Akron','Home',None,0,URLS['UGA']),
 (2027,'Texas'):('New Mexico State','Home',None,0,'https://texaslonghorns.com/sports/2013/7/27/FB_0727133417'),
 (2028,'Texas'):('Louisiana Tech','Home',None,0,'https://texaslonghorns.com/sports/2013/7/27/FB_0727133417'),
 (2029,'Texas'):('Louisiana-Monroe','Home',None,1,'https://texaslonghorns.com/sports/2013/7/27/FB_0727133417'),
 (2030,'Texas'):('UTSA','Home',None,2,'https://texaslonghorns.com/sports/2013/7/27/FB_0727133417'),
 (2031,'Texas'):('UTEP','Home',None,2,'https://texaslonghorns.com/sports/2013/7/27/FB_0727133417'),
 (2027,'Tennessee'):('Western Michigan','Home',None,3,'https://utsports.com/news/2026/9/30/football-moves-2027-and-2028-season-opener-dates'),
 (2028,'Tennessee'):('Central Michigan','Home',None,2,'https://utsports.com/news/2026/9/30/football-moves-2027-and-2028-season-opener-dates'),
 (2027,'Ole Miss'):('Charlotte','Home',None,1,'https://olemisssports.com/news/2020/6/30/football-schedules-home-and-home-series-with-charlotte'),
 (2028,'Ole Miss'):('South Alabama','Home',None,1,'https://olemisssports.com/news/2020/5/26/football-announces-future-home-and-home-series'),
 (2029,'Ole Miss'):('South Alabama','Away',None,0,'https://olemisssports.com/news/2020/5/26/football-announces-future-home-and-home-series'),
 (2030,'Ole Miss'):('Oregon State','Away',None,0,'https://olemisssports.com/news/2019/12/11/football-announces-future-home-and-home-series')}
# adjacency of US states to give regional weight
REGION={
'AL':'SE','AR':'South','AZ':'SW','CA':'West','CO':'Rockies','CT':'NE','DE':'MidAtl','FL':'SE','GA':'SE','HI':'Pacific','IA':'Midwest','ID':'Rockies','IL':'Midwest','IN':'Midwest','KS':'Plains','KY':'South','LA':'South','MA':'NE','MD':'MidAtl','MI':'Midwest','MN':'Midwest','MO':'Midwest','MS':'South','MT':'Rockies','NC':'SE','ND':'Plains','NE':'Plains','NH':'NE','NJ':'MidAtl','NM':'SW','NV':'West','NY':'NE','OH':'Midwest','OK':'Plains','OR':'West','PA':'MidAtl','RI':'NE','SC':'SE','SD':'Plains','TN':'South','TX':'South','UT':'Rockies','VA':'MidAtl','VT':'NE','WA':'West','WI':'Midwest','WV':'MidAtl','WY':'Rockies'}
NEAR={'SE':{'South','MidAtl'},'South':{'SE','Plains','Midwest'},'Midwest':{'South','Plains','NE'},'MidAtl':{'SE','NE','Midwest'},'NE':{'MidAtl','Midwest'},'Plains':{'South','Rockies','Midwest'},'Rockies':{'Plains','West','SW'},'West':{'Rockies','SW','Pacific'},'SW':{'Rockies','West','Plains'},'Pacific':{'West'}}
def g6_assign():
 result=[];year_count=collections.Counter();totalpair=collections.Counter();g6use=collections.Counter()
 for y in YR:
  for t in ALL:
   if (y,t) in G6_FIX:
    g,side,venue,w,src=G6_FIX[(y,t)]
   else:
    myreg=REGION[ST[t]]
    def rating(g):
     r=REGION[GST[g]]
     region=0 if ST[t]==GST[g] else (1 if r==myreg else (3 if r in NEAR[myreg] else 9))
     return region*4+totalpair[(t,g)]*13+year_count[(y,g)]*6+g6use[g]*.13+RNG.random()*3
    g=min((x for x in GG if x!='Navy' or t=='Notre Dame' or y not in (2027,2028,2029,2030,2031)),key=rating)
    # all others may use Navy provided different slot though selecting non-ND Navy would overdo it, avoid.
    if g=='Navy' and t!='Notre Dame':g=min([x for x in GG if x!='Navy'],key=rating)
    side='Home';venue=None;w=None;src='Model-generated regional G6 pairing'
   if t!='Notre Dame':
    side='Home';venue=None  # user rule overrides even previously published away/neutral G6 venues
   result.append((y,t,g,side,venue,w,src));year_count[(y,g)]+=1;totalpair[(t,g)]+=1;g6use[g]+=1
 return result

def physical_venue(y,h,a):
 if frozenset((h,a))==frozenset(('Georgia','Florida')):return ('Raymond James Stadium, Tampa, FL' if y==2027 else 'EverBank Stadium, Jacksonville, FL','Neutral (administrative home)')
 if frozenset((h,a))==frozenset(('Texas','Oklahoma')):return ('Cotton Bowl Stadium, Dallas, TX','Neutral (administrative home)')
 return (h+' campus','Campus')

def make_game_records(confgames,nonconf,g6):
 games=[];gameidx=set();ht=collections.Counter()
 def insert(y,h,a,kind,conf,venue=None,neutral=False,tag='Modeled',src='',pinned=None):
  k=(y,tuple(sorted((h,a))))
  if k in gameidx:raise ValueError('duplicate '+str(k))
  gameidx.add(k)
  games.append({'Year':y,'Home':h,'Away':a,'Type':kind,'Conference':conf,'Venue':venue or(h+' campus'),
    'Site type':'Neutral' if neutral else 'Campus','Status':tag,'Source URL':src or '',
    'Requested week':pinned,'Game ID':f'{y}-{len(games)+1:04d}'})
  if h in ALL and not neutral:ht[(y,h)]+=1
 # conference
 for y,h,a,c in confgames:
  k=tuple(sorted((h,a)));venue,typ=physical_venue(y,h,a)
  fixed=k in FIXED_CONF[(c,y)]
  src=FIXED_SOURCE.get((y,k),(URLS[c],))[0] if fixed else ''
  pinned=None
  if frozenset((h,a))==frozenset(('Georgia','Florida')):pinned=9
  if frozenset((h,a))==frozenset(('Texas','Oklahoma')):pinned=6
  insert(y,h,a,'Conference',c,venue,typ.startswith('Neutral'),'Published' if fixed else 'Modeled rotation',src,pinned)
 # All G6 games take place on the P4 team's campus, except Notre Dame vs Navy.
 # Published original venues that conflict are labeled as overridden, not preserved as published.
 for y,t,g,side,venue,w,src in g6:
  fixed=(y,t) in G6_FIX
  if t != 'Notre Dame':
   original=G6_FIX.get((y,t))
   changed=original is not None and (original[1]!='Home' or original[2] is not None)
   insert(y,t,g,'G6',GC[g],t+' campus',False,'Venue override' if changed else ('Published' if fixed else 'Modeled regional'),src,w)
  else:
   h,a=(t,g) if side in ('Home','Neutral') else(g,t)
   insert(y,h,a,'G6',GC[g],venue or (h+' campus' if side!='Neutral' else 'neutral site to be confirmed'),side=='Neutral','Published' if fixed else 'Modeled regional',src,w)
 # nonconference: fixed first, then free ordered by number of remaining home games
 byy=collections.defaultdict(list)
 for y,a,b in nonconf:byy[y].append((a,b))
 for y in YR:
  pairs=byy[y]
  fixedlist=[p for p in pairs if p in FIXED_X[y]]
  free=[p for p in pairs if p not in FIXED_X[y]]
  for k in fixedlist:
   h,a=FIXED_X[y][k];spec=GAME_SPECIAL.get((y,k),{})
   venue=spec.get('venue')
   note=X_SOURCE.get((y,k),('',''))[1]
   if venue:insert(y,h,a,'P4 nonconference',TEAMCONF[a],venue,True,'Published',X_SOURCE[(y,k)][0],spec.get('week'))
   else:insert(y,h,a,'P4 nonconference',TEAMCONF[a],None,False,'Published' if note.startswith('Published') or 'Notre Dame' in note else 'Protected',X_SOURCE[(y,k)][0],spec.get('week'))
  for a,b in sorted(free,key=lambda p: RNG.random()):
   # 6/7 home games preferred, bias small conference differences
   def score(h,v):
    return abs((ht[(y,h)]+1)-7)+abs(ht[(y,v)]-7)+.2*abs(ht[(y,h)]-ht[(y,v)])+RNG.random()*.08
   h,v=(a,b) if score(a,b)<=score(b,a) else(b,a)
   insert(y,h,v,'P4 nonconference',TEAMCONF[v],None,False,'Model generated', '', None)
 return games

RIVALRY_LAST=[('Georgia','Georgia Tech'),('Florida','Florida State'),('Clemson','South Carolina'),('Kentucky','Louisville'),
 ('Michigan','Ohio State'),('Alabama','Auburn'),('Ole Miss','Mississippi State'),('Missouri','Arkansas'),
 ('Tennessee','Vanderbilt'),('Indiana','Purdue'),('Iowa','Nebraska'),('Illinois','Northwestern'),
 ('Minnesota','Wisconsin'),('UCLA','USC'),('Oregon','Washington'),('Kansas','Kansas State'),
 ('Oklahoma State','Oklahoma'),('Texas','Texas A&M'),('Arizona','Arizona State'),('BYU','Utah'),
 ('Baylor','TCU'),('Virginia','Virginia Tech'),('North Carolina','NC State'),('Maryland','Rutgers'),
 ('Pitt','West Virginia'),('Boston College','Syracuse')]
LAST_KEYS=set(map(frozenset,RIVALRY_LAST))

def saturdays(y):
 # Always 14 calendar weeks from final rivalry weekend, backtrack 13 Saturdays
 last=max(d for dd in range(24,31) if (d:=datetime.date(y,11,dd)).weekday()==5)
 return [last-datetime.timedelta(weeks=13-w) for w in range(14)]

def slot_weeks(games):
 byy=collections.defaultdict(list)
 for g in games:byy[g['Year']].append(g)
 for y in sorted(byy):
  gl=byy[y];n=len(gl);N=n*14;dates=saturdays(y)
  fixed={}
  for i,g in enumerate(gl):
   k=frozenset((g['Home'],g['Away']))
   if g['Requested week'] is not None:fixed[i]=g['Requested week']
   if k in LAST_KEYS and g['Type']!='G6' and k not in [frozenset(('Oklahoma','Oklahoma State'))]:
    if k==frozenset(('Stanford','California')):fixed[i]=12
    elif k==frozenset(('Iowa','Iowa State')):fixed[i]=2
    else:fixed[i]=13
   if k==frozenset(('California','Stanford')):fixed[i]=12
   if k==frozenset(('Iowa','Iowa State')):fixed[i]=2
  # conflicts among mandatory slots
  seen=collections.defaultdict(list)
  for i,w in fixed.items():
   for t in (gl[i]['Home'],gl[i]['Away']):seen[(t,w)].append(i)
  bad={k:[(gl[i]['Home'],gl[i]['Away']) for i in v] for k,v in seen.items() if len(v)>1}
  if bad:
   print('PRE-ASSIGNMENT COLLISION',y,bad,flush=True)
   # honor published hard dates over modeled rivalry desire; de-pin less grounded
   for (t,w),indices in list(seen.items()):
    if len(indices)>1:
     keep=sorted(indices,key=lambda i:(gl[i]['Requested week'] is None,gl[i]['Type']=='G6'))[0]
     for i in indices:
      if i!=keep and i in fixed:del fixed[i]
  # mild timing preferences: nonconfs early, SEC rivalry late, conference middle
  lb=np.zeros(N);ub=np.ones(N);cost=np.zeros(N)
  for i,g in enumerate(gl):
   for w in range(14):
    j=i*14+w
    if g['Type']=='Conference':
     cost[j]=(.48 if w<3 else (.13 if w<5 else .01))+(.12 if w==0 else 0)
    elif g['Type']=='P4 nonconference':
     cost[j]=(.075*max(0,w-3)) + (.45 if w>=10 else 0)
    else:
     cost[j]=(.11*max(0,w-4)) +(.7 if w>=10 else 0)
    cost[j]+=RNG.random()*.012
    if i in fixed:lb[j]=ub[j]=1 if fixed[i]==w else 0
  rr=[];cc=[];vv=[];lo=[];hi=[]
  def add(ids,L,H):
   rid=len(lo);lo.append(L);hi.append(H)
   for j in ids:rr.append(rid);cc.append(j);vv.append(1)
  for i in range(n):add([i*14+w for w in range(14)],1,1)
  who=collections.defaultdict(list)
  for i,g in enumerate(gl):
   for t in (g['Home'],g['Away']):who[t].append(i)
  for t,indices in who.items():
   for w in range(14):add([i*14+w for i in indices],0,1)
  # weekly maximum 34 FBS power teams and minimum 24, avoids zero-week dumps
  for w in range(14):
   add([i*14+w for i,g in enumerate(gl) if g['Type']!='G6'],19,34)
  # 2027–2031 each P4 program must play at least 2 games in first 4 weeks, keeps meaningful early season
  for t in ALL:
   add([i*14+w for i in who[t] for w in range(4)],2,4)
  A=coo_matrix((vv,(rr,cc)),shape=(len(lo),N)).tocsr()
  t0=time.time();res=milp(cost,integrality=np.ones(N),bounds=Bounds(lb,ub),constraints=LinearConstraint(A,lo,hi),options={'time_limit':8,'mip_rel_gap':.35})
  print('WEEKS',y,res.status,res.message[:66],round(time.time()-t0,1),flush=True)
  if res.x is None:raise RuntimeError('Unable to week-slot '+str(y))
  for i,g in enumerate(gl):
   w=int(np.argmax(res.x[i*14:i*14+14]));g['Week']=w;g['Date']=dates[w].isoformat();g['Week label']=f'Week {w}'
 return games

# Full check: 5 yr, 12 games each, one G6, 11 Power, no duplicated same week, conference 8 or 9, ordered pair H/A coverage.
def validations(games):
 issues=[];teamsum=[];weekcounts=collections.Counter();teamgames=collections.defaultdict(list)
 confsum=collections.defaultdict(list);pairseen=collections.Counter()
 for g in games:
  y=g['Year'];h=g['Home'];a=g['Away'];
  if h==a:issues.append(('Self-play',y,h,a))
  for t in [h,a]:
   if t in ALL:teamgames[(y,t)].append(g)
   weekcounts[(y,g['Week'],t)]+=1
  if g['Type']=='G6':
   if 'Notre Dame' in (h,a):
    if {h,a}!={'Notre Dame','Navy'}:issues.append(('Notre Dame G6 not Navy',y,h,a))
   elif h not in ALL or a in ALL or g['Site type']!='Campus' or g['Venue']!=h+' campus':
    issues.append(('G6 must be home at Power campus',y,h,a,g['Venue'],g['Site type']))
  if g['Type']=='Conference':
   confsum[(y,h)].append(g);confsum[(y,a)].append(g)
   pairseen[(h,a)]+=1
  if not g['Date']:issues.append(('Missing week',y,h,a))
 for y in YR:
  for t in ALL:
   gs=teamgames[(y,t)];cnt=collections.Counter(g['Type'] for g in gs)
   if len(gs)!=12:issues.append(('Games !=12',y,t,len(gs)))
   if cnt['G6']!=1:issues.append(('G6 !=1',y,t,cnt['G6']))
   if cnt['Conference']+cnt['P4 nonconference']!=11:issues.append(('P4 !=11',y,t,cnt))
   if t!='Notre Dame' and len(confsum[(y,t)])!=(8 if TEAMCONF[t]=='ACC' and t=={2027:'Clemson',2028:'Stanford',2029:'SMU',2030:'California',2031:'Boston College'}[y] else 9):issues.append(('Conf mandates',y,t,len(confsum[(y,t)])))
   if len(set(g['Week'] for g in gs))!=12:issues.append(('Duplicate week for team',y,t))
 for (y,w,t),v in weekcounts.items():
  if v>1:issues.append(('Weekly team collision',y,w,t,v))
 for c,teams in CONF.items():
  for h,a in itertools.permutations(teams,2):
   if pairseen[(h,a)]<1:issues.append(('Home away coverage missing',c,h,a))
 return issues

