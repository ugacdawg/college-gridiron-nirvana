import sys,json,collections
sys.path.insert(0,str(__import__('pathlib').Path(__file__).resolve().parent))
import cfb_model as m
con=[]
for c in m.CONF:
 rr=m.solve_conference(c,timelimit=30)
 if rr is None:raise RuntimeError(c)
 con += [(y,h,a,c) for y,h,a in rr]
json.dump(con,open('./cfb_conference_games.json','w'))
nc=m.solve_nonconference(con)
json.dump(nc,open('./cfb_nonconference_games.json','w'))
g6=m.g6_assign();json.dump(g6,open('./cfb_g6_games.json','w'))
print('counts',len(con),len(nc),len(g6),flush=True)
